# moisture training script
