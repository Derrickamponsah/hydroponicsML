# temperature training script
