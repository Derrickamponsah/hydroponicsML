# humidity training script
