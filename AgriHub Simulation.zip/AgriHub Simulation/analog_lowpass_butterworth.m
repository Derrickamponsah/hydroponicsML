% Design 4th order Butterworth LPF with 20 rad/s cutoff
order = 4;
fc = 20; % rad/s
[b, a] = butter(order, fc, 's');  % 's' for analog filter

disp('Numerator coefficients (b):');
disp(b)
disp('Denominator coefficients (a):');
disp(a)