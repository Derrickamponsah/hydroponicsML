order = 8;           % filter order
Fs = 10;             % sampling frequency
Fc = 1.0;            % cutoff frequency
fir_coeffs = fir1(order, Fc/(Fs/2));
fir_coeffs = fir_coeffs / sum(fir_coeffs);  % Normalize DC gain
